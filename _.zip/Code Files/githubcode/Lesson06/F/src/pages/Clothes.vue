<template>
    <div>
        <h1>Clothes</h1>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
        <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Mollitia dolore pariatur consequatur sint nostrum nesciunt labore. Rerum corrupti quas, fuga ad doloribus, a ipsam eaque cupiditate nihil alias provident animi!</p>
    </div>
</template>