<template>
    <div>
        Drink you searched for
        <p>{{$route.params.drink}}</p>    
    </div>
</template>
