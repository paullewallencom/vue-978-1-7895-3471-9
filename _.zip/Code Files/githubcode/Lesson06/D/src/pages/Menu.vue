<template>
    <div>
        You just ordered
        <img :src="'http://lorempixel.com/200/200/food/' + $route.params.id">    
    </div>
</template>
