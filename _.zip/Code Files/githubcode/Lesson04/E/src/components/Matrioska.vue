<template>
    <div>
        <h1>Matrioska</h1>
        <matrioska/>
    </div>

</template>

<script>
export default {
    name: 'matrioska'
}
</script>
