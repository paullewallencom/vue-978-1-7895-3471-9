<template>
    <div class="gold">
        <span v-bind:key='i' v-for="(coin, i) in 10">
           💰
        </span>
    </div>
</template>
