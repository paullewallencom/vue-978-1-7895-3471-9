<template>
    <h1>Bar</h1>
</template>
