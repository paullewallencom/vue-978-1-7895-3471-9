<template>
    <div>
        <p>{{greeting}}</p>
    </div>
</template>

<script>
export default {
    data() {
        return {
            greeting: 'Hello',
        }
    }
}
</script>
