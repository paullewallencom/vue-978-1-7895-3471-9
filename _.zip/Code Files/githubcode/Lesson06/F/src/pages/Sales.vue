<template>
    <h1>Sales</h1>
</template>
